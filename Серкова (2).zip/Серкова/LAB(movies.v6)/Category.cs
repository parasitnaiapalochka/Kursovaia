﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_movies_
{
    public enum Category
    {
        ACTION,
        THRILLER,
        COMEDY,
        DRAMA,
        HORROR,
        OTHER
    }

}
